--- This is a getter for [SET_HELI_TAIL_EXPLODE_THROW_DASHBOARD](#\_0x3EC8BF18AA453FE9)
-- @param heli The helicopter to check
-- @return Returns `true` if the helicopter's tail boom can break, `false` if it cannot.
function Global.IsHeliTailBoomBreakable(heli)
	return _in(0x23e46bd7, heli, _r)
end
