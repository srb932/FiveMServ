--- PERFORM_HTTP_REQUEST_INTERNAL
function Global.PerformHttpRequestInternal(requestData, requestDataLength)
	return _in(0x8e8cc653, _ts(requestData), requestDataLength, _ri)
end
