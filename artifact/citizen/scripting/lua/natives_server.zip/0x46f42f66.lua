--- GET_HELI_MAIN_ROTOR_DAMAGE_SCALE
-- @param heli The helicopter to check
-- @return Returns a value representing the damage scaling factor applied to the helicopter's main rotor. The value ranges from `0.0` (no damage scaling) to`  1.0 ` (full damage scaling).
function Global.GetHeliMainRotorDamageScale(heli)
	return _in(0xc37d668, heli, _rf)
end
