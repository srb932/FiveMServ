--- This native is a getter for [SET_HELI_TAIL_ROTOR_HEALTH](#\_0xFE205F38AAA58E5B)
-- @param vehicle The target vehicle.
-- @return Returns the health of the helicopter's rear rotor. The maximum health value is `1000`.
function Global.GetHeliRearRotorHealth(vehicle)
	return _in(0x33ee6e2b, vehicle, _rf)
end
