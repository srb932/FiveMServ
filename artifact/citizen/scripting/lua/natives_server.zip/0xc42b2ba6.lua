--- p1 is always 0 in R* scripts; and a quick disassembly seems to indicate that p1 is unused.
function Global.SetPedRandomComponentVariation(ped, p1)
	return _in(0x4111ba46, ped, p1)
end
