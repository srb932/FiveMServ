--- GET_TRAIN_CARRIAGE_ENGINE
-- @param train The entity handle.
-- @return The train engine carriage.
function Global.GetTrainCarriageEngine(train)
	return _in(0x95070fa, train, _ri)
end
