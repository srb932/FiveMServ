--- GET_PLAYER_MAX_HEALTH
-- @param playerSrc The player handle
function Global.GetPlayerMaxHealth(playerSrc)
	return _in(0x8154e470, _ts(playerSrc), _ri)
end
