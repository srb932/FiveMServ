--- GET_VEHICLE_NUMBER_PLATE_TEXT_INDEX
function Global.GetVehicleNumberPlateTextIndex(vehicle)
	return _in(0x499747b6, vehicle, _ri)
end
