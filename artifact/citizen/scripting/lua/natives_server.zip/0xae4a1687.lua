--- GET_IS_VEHICLE_PRIMARY_COLOUR_CUSTOM
function Global.GetIsVehiclePrimaryColourCustom(vehicle)
	return _in(0xd7ec8760, vehicle, _r)
end
