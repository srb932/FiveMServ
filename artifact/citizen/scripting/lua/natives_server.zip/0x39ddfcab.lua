--- SET_VEHICLE_NUMBER_PLATE_TEXT
-- @param vehicle The vehicle to set the plate for
-- @param plateText The text to set the plate to, 8 chars maximum
function Global.SetVehicleNumberPlateText(vehicle, plateText)
	return _in(0x400f9556, vehicle, _ts(plateText))
end
