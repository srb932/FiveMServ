--- HAS_VEHICLE_BEEN_DAMAGED_BY_BULLETS
-- @param vehicle The target vehicle.
-- @return Returns whether or not the target vehicle has been damaged by bullets.
function Global.HasVehicleBeenDamagedByBullets(vehicle)
	return _in(0xb8af3137, vehicle, _r)
end
