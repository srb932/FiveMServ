--- Make the player impervious to all forms of damage.
-- @param player The player index.
function Global.SetPlayerInvincible(player, bInvincible)
	return _in(0xdfb9a2a2, _ts(player), bInvincible)
end
