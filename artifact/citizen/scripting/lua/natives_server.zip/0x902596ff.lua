--- EXECUTE_COMMAND
function Global.ExecuteCommand(commandString)
	return _in(0x561c060b, _ts(commandString))
end
