--- GET_PED_STEALTH_MOVEMENT
-- @param ped The target ped.
-- @return Whether or not the ped is stealthy.
function Global.GetPedStealthMovement(ped)
	return _in(0x40321b83, ped, _r)
end
