--- NETWORK_GET_ENTITY_FROM_NETWORK_ID
function Global.NetworkGetEntityFromNetworkId(netId)
	return _in(0x5b912c3f, netId, _ri)
end
