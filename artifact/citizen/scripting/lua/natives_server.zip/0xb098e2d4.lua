--- END_FIND_KVP
-- @param handle The KVP find handle returned from [START_FIND_KVP](#\_0xDD379006)
-- @return None.
function Global.EndFindKvp(handle)
	return _in(0xb3210203, handle)
end
