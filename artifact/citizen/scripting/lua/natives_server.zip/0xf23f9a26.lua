--- CLEAR_PED_PROP
-- @param ped The ped handle.
-- @param propId The prop id you want to clear from the ped. Refer to [SET_PED_PROP_INDEX](#\_0x93376B65A266EB5F).
function Global.ClearPedProp(ped, propId)
	return _in(0x2d23d743, ped, propId)
end
