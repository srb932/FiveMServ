--- START_RESOURCE
function Global.StartResource(resourceName)
	return _in(0x29b440dc, _ts(resourceName), _r)
end
