--- ```
-- NativeDB Introduced: v323
-- ```
-- Warp a ped into a vehicle.
-- **Note**: It's better to use [`TASK_ENTER_VEHICLE`](#\_0xC20E50AA46D09CA8) with the flag "warp" flag instead of this native.
-- @param ped The Ped to be warped into the vehicle.
-- @param vehicle The target vehicle into which the ped will be warped.
-- @param seatIndex See eSeatPosition declared in [`IS_VEHICLE_SEAT_FREE`](#\_0x22AC59A870E6A669).
function Global.TaskWarpPedIntoVehicle(ped, vehicle, seatIndex)
	return _in(0x65d4a35d, ped, vehicle, seatIndex)
end
