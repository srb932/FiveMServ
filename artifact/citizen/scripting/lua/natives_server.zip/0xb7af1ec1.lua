--- GET_HELI_TAIL_ROTOR_DAMAGE_SCALE
-- @param heli The helicopter to check
-- @return Returns a value representing the damage scaling factor applied to the helicopter's tail rotor. The value ranges from `0.0` (no damage scaling) to`  1.0 ` (full damage scaling).
function Global.GetHeliTailRotorDamageScale(heli)
	return _in(0x22239130, heli, _rf)
end
